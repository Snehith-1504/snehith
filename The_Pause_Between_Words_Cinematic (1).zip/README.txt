The Pause Between Words - Cinematic Version

Instructions:
1. This is a single-page cinematic website showcasing reflective writings by Snehith.
2. Open `index.html` in a browser to preview locally.
3. Upload the folder or `index.html` directly to Netlify Drop (https://app.netlify.com/drop) to go live.
4. The music toggle (bottom-right 🎵) controls the ambient rain + piano track, fading between sections.
5. Sections fade in and text moves subtly for a cinematic reading experience.
6. Background color changes per section to match the mood.
